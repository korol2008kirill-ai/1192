// общие обработчики: формы, выход, покупка, чат ассистента, статистика

const $ = (sel, root = document) => root.querySelector(sel);

async function callApi(url, body, method = 'POST') {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  let data = {};
  try { data = await res.json(); } catch (e) { /* пустой ответ */ }
  return { ok: res.ok, status: res.status, data };
}

function formData(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function flash(el, text, ok) {
  el.textContent = text;
  el.hidden = false;
  el.classList.toggle('ok', !!ok);
  el.classList.toggle('err', !ok);
}

/* формы с data-api: login, register, reset */
document.querySelectorAll('form[data-api]').forEach(form => {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const err = form.querySelector('.form-error');
    if (err) err.hidden = true;
    const btn = form.querySelector('button[type=submit]');
    if (btn) btn.disabled = true;

    const res = await callApi(form.dataset.api, formData(form));
    if (btn) btn.disabled = false;

    if (!res.ok) {
      if (err) { err.textContent = res.data.error || 'Ошибка'; err.hidden = false; }
      return;
    }
    if (form.dataset.showOnOk) {
      form.hidden = true;
      const next = document.querySelector(form.dataset.showOnOk);
      if (next) next.hidden = false;
      return;
    }
    location.href = form.dataset.redirect || '/';
  });
});

/* выход */
document.addEventListener('click', async e => {
  if (e.target.closest('[data-logout]')) {
    await callApi('/api/logout', {});
    location.href = '/';
    return;
  }

  /* покупка билета на главной */
  const buy = e.target.closest('[data-buy]');
  if (buy) {
    buy.disabled = true;
    const res = await callApi('/api/tickets', {
      train_id: buy.dataset.train,
      class: buy.dataset.class
    });
    buy.disabled = false;
    if (res.status === 401) return (location.href = '/login');
    if (!res.ok) return alert(res.data.error || 'Не удалось купить билет');
    alert('Билет куплен. Он появится в разделе «Мои билеты».');
    location.href = '/tickets';
  }
});

/* чат ассистента */
const chat = {
  toggle: $('#chatToggle'),
  panel: $('#chatPanel'),
  body: $('#chatBody'),
  form: $('#chatForm'),
  input: $('#chatText')
};

function addMessage(text, who) {
  const div = document.createElement('div');
  div.className = 'msg ' + (who === 'user' ? 'msg-user' : 'msg-bot');
  div.textContent = text;
  chat.body.appendChild(div);
  chat.body.scrollTop = chat.body.scrollHeight;
}

async function askAssistant(payload, label) {
  addMessage(label, 'user');
  const res = await callApi('/api/assistant', payload);
  addMessage(res.ok ? res.data.answer : 'Не удалось получить ответ. Попробуйте ещё раз.', 'bot');
}

if (chat.toggle) {
  let greeted = false;
  const open = () => {
    chat.panel.hidden = false;
    chat.toggle.hidden = true;
    if (!greeted) {
      greeted = true;
      addMessage('Здравствуйте! Выберите тему кнопкой или напишите вопрос.', 'bot');
    }
    chat.input.focus();
  };
  chat.toggle.addEventListener('click', open);
  $('#chatClose').addEventListener('click', () => {
    chat.panel.hidden = true;
    chat.toggle.hidden = false;
  });

  document.querySelectorAll('.chat-quick [data-topic]').forEach(btn => {
    btn.addEventListener('click', () => askAssistant({ topic: btn.dataset.topic }, btn.textContent));
  });

  chat.form.addEventListener('submit', e => {
    e.preventDefault();
    const text = chat.input.value.trim();
    if (!text) return;
    chat.input.value = '';
    askAssistant({ text }, text);
  });
}

/* статистика для админа */
const TOPIC_LABELS = {
  search: 'Поиск поездов',
  buy: 'Покупка билетов',
  orders: 'Мои билеты',
  return: 'Возврат',
  password: 'Пароль',
  unknown: 'Без ответа'
};

async function loadStats() {
  const statsEl = $('#stats');
  if (!statsEl) return;
  const res = await callApi('/api/admin/assistant-stats', undefined, 'GET');
  if (!res.ok) {
    flash($('#statsError'), res.data.error || 'Не удалось загрузить статистику', false);
    return;
  }
  const s = res.data;
  statsEl.hidden = false;
  $('#sTotal').textContent = s.total.toLocaleString('ru-RU');
  $('#sShare').textContent = s.answeredShare + '%';

  // по дням
  const days = $('#sDays');
  days.innerHTML = '';
  const maxDay = Math.max(1, ...s.byDay.map(d => d.n));
  s.byDay.forEach(d => {
    const wrap = document.createElement('div');
    wrap.className = 'bar-wrap';
    wrap.innerHTML = '<div class="bar" style="height:' + Math.round((d.n / maxDay) * 100) + '%"></div>' +
      '<div class="bar-label">' + new Date(d.day).toLocaleDateString('ru-RU', { day: 'numeric', month: 'numeric' }) + '</div>';
    wrap.querySelector('.bar').title = d.n + ' обращений';
    days.appendChild(wrap);
  });
  if (!s.byDay.length) days.textContent = 'Пока нет обращений';

  // по темам
  const topics = $('#sTopics');
  topics.innerHTML = '';
  const maxTopic = Math.max(1, ...s.byTopic.map(t => t.n));
  s.byTopic.forEach(t => {
    const row = document.createElement('div');
    const pct = Math.round((t.n / s.total) * 100);
    row.innerHTML = '<div class="topic-row"><span></span><span>' + pct + '%</span></div>' +
      '<div class="progress"><div class="progress-fill" style="width:' + Math.round((t.n / maxTopic) * 100) + '%"></div></div>';
    row.querySelector('span').textContent = TOPIC_LABELS[t.topic] || t.topic;
    topics.appendChild(row);
  });
  if (!s.byTopic.length) topics.textContent = 'Пока нет обращений';

  // без ответа: текст вопроса выводим через textContent
  const list = $('#sUnanswered');
  list.innerHTML = '';
  s.unanswered.forEach(u => {
    const row = document.createElement('div');
    row.className = 'unanswered';
    const q = document.createElement('span');
    q.textContent = u.question;
    const n = document.createElement('span');
    n.className = 'muted';
    n.textContent = u.n + ' раз';
    row.append(q, n);
    list.appendChild(row);
  });
  if (!s.unanswered.length) list.textContent = 'Всё хорошо, вопросов без ответа нет.';
}

loadStats();
