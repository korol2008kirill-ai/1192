// общие обработчики: формы, выход, покупка, возврат, чат ассистента, статистика

const $ = (sel, root = document) => root.querySelector(sel);

async function callApi(url, body, method = 'POST') {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  let data = {};
  try { data = await res.json(); } catch (e) { /* пустой ответ */ }
  return { ok: res.ok, status: res.status, data };
}

function formData(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function flash(el, text, ok) {
  el.textContent = text;
  el.hidden = false;
  el.classList.toggle('ok', !!ok);
  el.classList.toggle('err', !ok);
}

/* формы с data-api: login, register, reset */
document.querySelectorAll('form[data-api]').forEach(form => {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const err = form.querySelector('.form-error');
    if (err) err.hidden = true;
    const btn = form.querySelector('button[type=submit]');
    if (btn) btn.disabled = true;

    const res = await callApi(form.dataset.api, formData(form));
    if (btn) btn.disabled = false;

    if (!res.ok) {
      if (err) { err.textContent = res.data.error || 'Ошибка'; err.hidden = false; }
      return;
    }
    if (form.dataset.showOnOk) {
      form.hidden = true;
      const next = document.querySelector(form.dataset.showOnOk);
      if (next) next.hidden = false;
      return;
    }
    location.href = form.dataset.redirect || '/';
  });
});

/* клики: выход, покупка, возврат */
document.addEventListener('click', async e => {
  if (e.target.closest('[data-logout]')) {
    await callApi('/api/logout', {});
    location.href = '/';
    return;
  }

  const buy = e.target.closest('[data-buy]');
  if (buy) {
    buy.disabled = true;
    const res = await callApi('/api/tickets', {
      train_id: buy.dataset.train,
      class: buy.dataset.class
    });
    buy.disabled = false;
    if (res.status === 401) return (location.href = '/login');
    if (!res.ok) return alert(res.data.error || 'Не удалось купить билет');
    alert('Билет куплен. Он появится в разделе «Мои билеты».');
    location.href = '/tickets';
    return;
  }

  const ret = e.target.closest('[data-return]');
  if (ret) {
    if (!confirm('Вернуть билет? Это действие нельзя отменить.')) return;
    ret.disabled = true;
    const res = await callApi(`/api/tickets/${ret.dataset.ticket}/return`, {});
    if (!res.ok) {
      ret.disabled = false;
      return alert(res.data.error || 'Не удалось вернуть билет');
    }
    location.reload();
  }
});

/* чат ассистента: плавающая кнопка справа внизу */
const chat = {
  toggle: $('#chatToggle'),
  panel: $('#chatPanel'),
  body: $('#chatBody'),
  form: $('#chatForm'),
  input: $('#chatText')
};

function addMessage(text, who, links = []) {
  const div = document.createElement('div');
  div.className = 'msg ' + (who === 'user' ? 'msg-user' : 'msg-bot');
  div.textContent = text;
  chat.body.appendChild(div);

  if (links.length) {
    const box = document.createElement('div');
    box.className = 'msg-links';
    links.forEach(l => {
      const link = document.createElement('a');
      link.href = l.href;
      link.textContent = l.text;
      box.appendChild(link);
    });
    chat.body.appendChild(box);
  }
  chat.body.scrollTop = chat.body.scrollHeight;
}

async function askAssistant(payload, label) {
  addMessage(label, 'user');
  const res = await callApi('/api/assistant', payload);
  if (!res.ok) return addMessage(res.data.error || 'Не удалось получить ответ. Попробуйте ещё раз.', 'bot');
  addMessage(res.data.answer, 'bot', res.data.links || []);
}

if (chat.toggle) {
  let greeted = false;
  const open = () => {
    chat.panel.hidden = false;
    chat.toggle.hidden = true;
    if (!greeted) {
      greeted = true;
      addMessage('Здравствуйте! Напишите, откуда и куда едете, например «Москва Казань завтра», или выберите тему кнопкой.', 'bot');
    }
    chat.input.focus();
  };
  chat.toggle.addEventListener('click', open);
  $('#chatClose').addEventListener('click', () => {
    chat.panel.hidden = true;
    chat.toggle.hidden = false;
  });

  document.querySelectorAll('.chat-quick [data-topic]').forEach(btn => {
    btn.addEventListener('click', () => askAssistant({ topic: btn.dataset.topic }, btn.textContent));
  });

  chat.form.addEventListener('submit', e => {
    e.preventDefault();
    const text = chat.input.value.trim();
    if (!text) return;
    chat.input.value = '';
    askAssistant({ text }, text);
  });
}

/* админ-панель: вкладки */
const TOPIC_LABELS = {
  search: 'Поиск рейсов', buy: 'Покупка билетов', orders: 'Мои билеты',
  return: 'Возврат', password: 'Пароль', hello: 'Приветствие', unknown: 'Без ответа'
};

// таблица из массива объектов: колонки [ключ, заголовок, функция-форматтер?]
function renderTable(el, columns, rows, actionsFor) {
  el.innerHTML = '';
  if (!rows.length) { el.textContent = 'Пока пусто'; return; }
  const table = document.createElement('table');
  table.className = 'admin-table';
  const head = document.createElement('tr');
  columns.forEach(c => { const th = document.createElement('th'); th.textContent = c[1]; head.appendChild(th); });
  if (actionsFor) head.appendChild(document.createElement('th'));
  table.appendChild(head);
  rows.forEach(r => {
    const tr = document.createElement('tr');
    columns.forEach(c => {
      const td = document.createElement('td');
      td.textContent = c[2] ? c[2](r[c[0]], r) : (r[c[0]] ?? '');
      tr.appendChild(td);
    });
    if (actionsFor) {
      const td = document.createElement('td');
      actionsFor(r, td);
      tr.appendChild(td);
    }
    table.appendChild(tr);
  });
  el.appendChild(table);
}

const fmtDate = v => v ? new Date(v).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';

function showTab(name) {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab-pane').forEach(p => { p.hidden = p.dataset.pane !== name; });
  if (name === 'stats') loadStats();
  if (name === 'trains') loadTrains();
  if (name === 'users') loadUsers();
  if (name === 'admins') loadAdmins();
  if (name === 'tickets') loadTickets();
}

function renderUnanswered(items) {
  const list = $('#sUnanswered');
  list.innerHTML = '';
  if (!items.length) { list.textContent = 'Всё хорошо, вопросов без ответа нет.'; return; }
  items.forEach(u => {
    const row = document.createElement('div');
    row.className = 'unanswered';
    const q = document.createElement('span');
    q.className = 'unanswered-q';
    q.textContent = u.question;
    const n = document.createElement('span');
    n.className = 'muted';
    n.textContent = u.n + ' раз';
    const del = document.createElement('button');
    del.textContent = 'Удалить';
    del.addEventListener('click', async () => {
      if (!confirm('Удалить этот вопрос из списка?')) return;
      const r = await callApi('/api/admin/assistant-unanswered/delete', { question: u.question });
      if (!r.ok) return alert(r.data.error || 'Не удалось удалить');
      loadStats();
    });
    row.append(q, n, del);
    list.appendChild(row);
  });
}

async function loadStats() {
  const statsEl = $('#stats');
  const res = await callApi('/api/admin/assistant-stats', undefined, 'GET');
  if (!res.ok) return flash($('#statsError'), res.data.error || 'Не удалось загрузить статистику', false);
  const s = res.data;
  $('#sTotal').textContent = s.total.toLocaleString('ru-RU');
  $('#sShare').textContent = s.answeredShare + '%';

  const days = $('#sDays');
  days.innerHTML = '';
  const maxDay = Math.max(1, ...s.byDay.map(d => d.n));
  s.byDay.forEach(d => {
    const wrap = document.createElement('div');
    wrap.className = 'bar-wrap';
    wrap.innerHTML = '<div class="bar"></div><div class="bar-label"></div>';
    wrap.querySelector('.bar').style.height = Math.round((d.n / maxDay) * 100) + '%';
    wrap.querySelector('.bar').title = d.n + ' обращений';
    wrap.querySelector('.bar-label').textContent =
      new Date(d.day).toLocaleDateString('ru-RU', { day: 'numeric', month: 'numeric' });
    days.appendChild(wrap);
  });
  if (!s.byDay.length) days.textContent = 'Пока нет обращений';

  const topics = $('#sTopics');
  topics.innerHTML = '';
  const maxTopic = Math.max(1, ...s.byTopic.map(t => t.n));
  s.byTopic.forEach(t => {
    const row = document.createElement('div');
    const pct = Math.round((t.n / s.total) * 100);
    row.innerHTML = '<div class="topic-row"><span></span><span>' + pct + '%</span></div>' +
      '<div class="progress"><div class="progress-fill"></div></div>';
    row.querySelector('span').textContent = TOPIC_LABELS[t.topic] || t.topic;
    row.querySelector('.progress-fill').style.width = Math.round((t.n / maxTopic) * 100) + '%';
    topics.appendChild(row);
  });
  if (!s.byTopic.length) topics.textContent = 'Пока нет обращений';

  renderUnanswered(s.unanswered);

}

async function loadTrains() {
  const res = await callApi('/api/admin/trains', undefined, 'GET');
  renderTable($('#trainList'), [
    ['number', 'Номер'], ['name', 'Название'], ['from_city', 'Откуда'], ['to_city', 'Куда'],
    ['depart_at', 'Отправление', fmtDate], ['price_econom', 'Эконом, ₽'], ['price_coupe', 'Купе, ₽']
  ], res.data, (r, td) => {
    const btn = document.createElement('button');
    btn.textContent = 'Удалить';
    btn.addEventListener('click', async () => {
      if (!confirm('Удалить рейс ' + r.number + '?')) return;
      const del = await callApi('/api/admin/trains/' + r.id, undefined, 'DELETE');
      if (!del.ok) return alert(del.data.error || 'Не удалось удалить');
      loadTrains();
    });
    td.appendChild(btn);
  });
}

async function loadUsers() {
  const res = await callApi('/api/admin/users', undefined, 'GET');
  renderTable($('#userList'), [
    ['login', 'Логин'], ['email', 'E-mail'], ['is_admin', 'Админ', v => v ? 'да' : 'нет'],
    ['created_at', 'Регистрация', fmtDate]
  ], res.data, (r, td) => {
    const btn = document.createElement('button');
    btn.textContent = r.is_admin ? 'Снять админа' : 'Сделать админом';
    btn.addEventListener('click', async () => {
      const up = await callApi('/api/admin/users/' + r.id + '/admin', { is_admin: !r.is_admin });
      if (!up.ok) return alert(up.data.error || 'Не удалось изменить');
      loadUsers();
    });
    td.appendChild(btn);
  });
}

async function loadAdmins() {
  const errBox = $('#adminListError');
  errBox.hidden = true;
  const res = await callApi('/api/admin/admins', undefined, 'GET');
  if (!res.ok) return flash(errBox, res.data.error || 'Не удалось загрузить администраторов', false);

  renderTable($('#adminList'), [
    ['login', 'Логин'],
    ['email', 'E-mail'],
    ['created_at', 'Создан', fmtDate],
    ['is_main', 'Роль', (v, r) => v ? 'главный' : (r.is_self ? 'это вы' : 'администратор')]
  ], res.data, (r, td) => {
    // главного администратора и самого себя менять нельзя
    if (r.is_main || r.is_self) {
      td.className = 'muted';
      td.textContent = r.is_main ? 'задан в .env' : 'нельзя изменить';
      return;
    }
    const revoke = document.createElement('button');
    revoke.textContent = 'Снять права';
    revoke.addEventListener('click', async () => {
      if (!confirm('Снять права администратора у ' + r.login + '? Аккаунт останется обычным пользователем.')) return;
      const up = await callApi('/api/admin/users/' + r.id + '/admin', { is_admin: false });
      if (!up.ok) return flash(errBox, up.data.error || 'Не удалось снять права', false);
      loadAdmins();
    });
    const del = document.createElement('button');
    del.textContent = 'Удалить';
    del.addEventListener('click', async () => {
      if (!confirm('Удалить администратора ' + r.login + '? Аккаунт и все его билеты будут удалены без возможности восстановления.')) return;
      const d = await callApi('/api/admin/admins/' + r.id, undefined, 'DELETE');
      if (!d.ok) return flash(errBox, d.data.error || 'Не удалось удалить', false);
      loadAdmins();
    });
    td.append(revoke, ' ', del);
  });
}

async function loadTickets() {
  const res = await callApi('/api/admin/tickets', undefined, 'GET');
  renderTable($('#ticketList'), [
    ['login', 'Пользователь'], ['number', 'Рейс'], ['from_city', 'Откуда'], ['to_city', 'Куда'],
    ['depart_at', 'Отправление', fmtDate], ['class', 'Класс', v => v === 'coupe' ? 'купе' : 'эконом'],
    ['created_at', 'Куплен', fmtDate]
  ], res.data);
}

if ($('.tabs')) {
  document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));
  const adminForm = $('#adminForm');
  if (adminForm) adminForm.addEventListener('submit', async e => {
    e.preventDefault();
    const err = $('#adminError');
    err.hidden = true;
    const btn = adminForm.querySelector('button[type=submit]');
    btn.disabled = true;
    const res = await callApi('/api/admin/admins', formData(adminForm));
    btn.disabled = false;
    if (!res.ok) return flash(err, res.data.error || 'Не удалось добавить администратора', false);
    adminForm.reset();
    loadAdmins();
  });

  const trainForm = $('#trainForm');
  if (trainForm) trainForm.addEventListener('submit', async e => {
    e.preventDefault();
    const err = $('#trainError');
    err.hidden = true;
    const res = await callApi('/api/admin/trains', formData(trainForm));
    if (!res.ok) return flash(err, res.data.error || 'Не удалось добавить рейс', false);
    trainForm.reset();
    loadTrains();
  });
  showTab('stats');
}
