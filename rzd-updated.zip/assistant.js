// Ассистент: отвечает по готовым шаблонам и по реальным рейсам из базы.
// Без внешних сервисов. Тема выбирается кнопкой в чате или по ключевым словам.

const TOPICS = ['search', 'buy', 'orders', 'return', 'password'];

const CANNED = {
  search: 'Чтобы найти поезд, напишите, откуда и куда едете, например: «Москва Казань завтра». Можно указать дату словами или числом, например 15.11.',
  buy: 'Чтобы купить билет, найдите поезд, нажмите «Эконом» или «Купе» и войдите в аккаунт. Купленный билет появится в разделе «Мои билеты».',
  orders: 'Все ваши билеты показаны в разделе «Мои билеты». Чтобы их увидеть, войдите в аккаунт.',
  return: 'Вернуть билет можно в разделе «Мои билеты», кнопкой «Вернуть». Возврат возможен только до отправления поезда, и билет сразу убирается из списка.',
  password: 'Если вы забыли пароль, откройте страницу «Вход» и перейдите по ссылке «Забыли пароль?». Введите логин и e-mail, затем код и новый пароль.',
  hello: 'Здравствуйте! Могу подсказать рейсы, цены, ваши билеты и как вернуть билет. Например, напишите: «Москва Казань завтра».',
  unknown: 'Не нашёл ответа на этот вопрос. Попробуйте назвать города и дату, например «Москва Санкт-Петербург 20.11», или выберите тему кнопкой.'
};

const CITY_ALIASES = {
  'спб': 'Санкт-Петербург',
  'питер': 'Санкт-Петербург',
  'мск': 'Москва',
  'нижний': 'Нижний Новгород',
  'новосиб': 'Новосибирск'
};

const MONTHS_RU = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];

// города из текста в порядке появления
function findCities(text, cities) {
  const found = [];
  const add = (name, index) => {
    if (!found.some(f => f.name === name)) found.push({ name, index });
  };
  for (const [alias, name] of Object.entries(CITY_ALIASES)) {
    const i = text.indexOf(alias);
    if (i !== -1 && cities.includes(name)) add(name, i);
  }
  for (const city of cities) {
    const stem = city.toLowerCase().slice(0, 5);
    const i = text.indexOf(stem);
    if (i !== -1) add(city, i);
  }
  return found.sort((a, b) => a.index - b.index).map(f => f.name);
}

// дата: «сегодня», «завтра», «послезавтра» или 15.11
function parseDate(text) {
  if (text.includes('послезавтра')) return { offset: 2 };
  if (text.includes('завтра')) return { offset: 1 };
  if (text.includes('сегодня')) return { offset: 0 };
  const m = text.match(/(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?/);
  if (m) {
    const day = m[1].padStart(2, '0');
    const month = m[2].padStart(2, '0');
    const year = m[3] ? (m[3].length === 2 ? '20' + m[3] : m[3]) : String(new Date().getFullYear());
    return { iso: `${year}-${month}-${day}` };
  }
  return null;
}

function formatDateTime(d) {
  return new Date(d).toLocaleString('ru-RU', {
    timeZone: 'Europe/Moscow', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit'
  });
}

const KEYWORDS = {
  orders:   ['мои билет', 'мои заказ', 'мои поезд', 'какие у меня билет', 'история заказ'],
  return:   ['возврат', 'вернуть', 'отмен'],
  password: ['пароль', 'забыл', 'восстан'],
  buy:      ['купи', 'купить', 'оформ', 'заказать', 'бронь', 'забронировать'],
  price:    ['сколько стоит', 'цена', 'стоимость', 'сколько стоят', 'дешев'],
  hello:    ['привет', 'здравств', 'добрый день', 'добрый вечер', 'доброе утро'],
  search:   ['найти', 'поиск', 'расписан', 'поезд', 'рейс', 'когда', 'ближайш', 'отправ']
};

const hasAny = (text, words) => words.some(w => text.includes(w));

async function allCities(db) {
  const { rows } = await db.query(
    'SELECT from_city AS c FROM trains UNION SELECT to_city FROM trains ORDER BY c'
  );
  return rows.map(r => r.c);
}

// ближайшие рейсы с фильтрами
async function nextTrains(db, { from, to, date }, limit = 3) {
  const where = ['depart_at > now()'];
  const params = [];
  if (from) { params.push(from); where.push(`from_city = $${params.length}`); }
  if (to)   { params.push(to);   where.push(`to_city = $${params.length}`); }
  if (date && date.iso) {
    params.push(date.iso);
    where.push(`depart_at::date = $${params.length}::date`);
  } else if (date && date.offset !== undefined) {
    params.push(date.offset);
    where.push(`depart_at::date = current_date + $${params.length}::int`);
  }
  params.push(limit);
  const { rows } = await db.query(
    `SELECT id, number, name, from_city, to_city, depart_at, price_econom
     FROM trains WHERE ${where.join(' AND ')}
     ORDER BY depart_at LIMIT $${params.length}`,
    params
  );
  return rows;
}

function trainsReply(rows, title) {
  const lines = rows.map(t =>
    `• ${formatDateTime(t.depart_at)}, ${t.name} ${t.number}, от ${t.price_econom} ₽`
  );
  return {
    answer: `${title}\n${lines.join('\n')}`,
    links: rows.map(t => ({ text: `Рейс ${t.number} · ${formatDateTime(t.depart_at)}`, href: `/train/${t.id}` }))
  };
}

async function answer(db, { text = '', topic, user }) {
  const q = String(text).toLowerCase().trim();

  // кнопки в чате
  if (topic === 'orders' || topic === 'return' || topic === 'password' || topic === 'buy') {
    if (topic === 'orders' && user) return ordersReply(db, user);
    const links = topic === 'orders' && !user ? [{ text: 'Войти', href: '/login' }] : [];
    return { topic, answer: CANNED[topic], links };
  }
  if (topic === 'search') {
    return { topic: 'search', answer: CANNED.search, links: [{ text: 'Расписание по датам', href: '/dates' }] };
  }

  if (!q) return { topic: 'unknown', answer: CANNED.unknown, links: [] };

  // мои билеты
  if (hasAny(q, KEYWORDS.orders)) return ordersReply(db, user);

  // возврат и пароль
  if (hasAny(q, KEYWORDS.return))   return { topic: 'return', answer: CANNED.return, links: [{ text: 'Мои билеты', href: '/tickets' }] };
  if (hasAny(q, KEYWORDS.password)) return { topic: 'password', answer: CANNED.password, links: [{ text: 'Сброс пароля', href: '/reset' }] };

  // поиск рейсов по городам и дате
  const cities = await allCities(db);
  const found = findCities(q, cities);
  const date = parseDate(q);

  if (found.length >= 2) {
    const [from, to] = found;
    const rows = await nextTrains(db, { from, to, date });
    if (hasAny(q, KEYWORDS.price) && rows.length) {
      const min = Math.min(...rows.map(r => r.price_econom));
      return { topic: 'search', answer: `Самый дешёвый эконом на ближайшие рейсы ${from} → ${to} стоит от ${min} ₽.`,
        links: trainsReply(rows, '').links };
    }
    if (!rows.length) {
      return { topic: 'search', answer: `Рейсов ${from} → ${to} на эту дату не нашлось. Попробуйте другой день.`,
        links: [{ text: 'Расписание по датам', href: '/dates' }] };
    }
    const r = trainsReply(rows, `Ближайшие рейсы ${from} → ${to}:`);
    return { topic: 'search', answer: r.answer, links: r.links };
  }

  if (found.length === 1 && hasAny(q, KEYWORDS.search)) {
    const rows = await nextTrains(db, { from: found[0], date });
    if (!rows.length) {
      return { topic: 'search', answer: `Ближайших рейсов из ${found[0]} не нашлось.`, links: [] };
    }
    const r = trainsReply(rows, `Ближайшие рейсы из ${found[0]}:`);
    return { topic: 'search', answer: r.answer, links: r.links };
  }

  if (hasAny(q, KEYWORDS.buy))    return { topic: 'buy', answer: CANNED.buy, links: [{ text: 'Найти поезд', href: '/' }] };
  if (hasAny(q, KEYWORDS.hello))  return { topic: 'hello', answer: CANNED.hello, links: [] };
  if (hasAny(q, KEYWORDS.search)) return { topic: 'search', answer: CANNED.search, links: [{ text: 'Расписание по датам', href: '/dates' }] };

  return { topic: 'unknown', answer: CANNED.unknown, links: [{ text: 'Расписание', href: '/dates' }] };
}

async function ordersReply(db, user) {
  if (!user) return { topic: 'orders', answer: CANNED.orders, links: [{ text: 'Войти', href: '/login' }] };
  const { rows } = await db.query(
    `SELECT COUNT(*)::int AS n FROM tickets t JOIN trains tr ON tr.id = t.train_id
     WHERE t.user_id = $1 AND tr.depart_at > now()`, [user.id]
  );
  const n = rows[0].n;
  const word = n === 0 ? 'предстоящих билетов нет' : `предстоящих билетов: ${n}`;
  return { topic: 'orders', answer: `У вас ${word}. Все билеты в разделе «Мои билеты».`,
    links: [{ text: 'Мои билеты', href: '/tickets' }] };
}

module.exports = { answer, TOPICS, findCities, parseDate, formatDateTime };
