require('dotenv').config({ quiet: true });
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const path = require('path');
const db = require('./db');
const { applySchema, dbInfo, describe, errText, hintFor } = require('./setup-db');
const { answer, TOPICS, formatDateTime } = require('./assistant');

// учётная запись администратора: логин и пароль берутся из .env, если заданы
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'korol2008kirill@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'limpopo';

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

// текущий пользователь и помощники для шаблонов
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.fmt = formatDateTime;
  res.locals.fmtDay = d => new Date(d).toLocaleDateString('ru-RU', {
    timeZone: 'Europe/Moscow', weekday: 'short', day: 'numeric', month: 'long'
  });
  next();
});

const needAuth = (req, res, next) =>
  req.session.user ? next() : res.status(401).json({ error: 'Войдите в аккаунт' });

// роль проверяем в базе, а не только в сессии: снятие прав сразу действует
async function isAdmin(req) {
  if (!req.session.user) return false;
  const { rows } = await db.query('SELECT is_admin FROM users WHERE id = $1', [req.session.user.id]);
  return !!(rows[0] && rows[0].is_admin);
}

const needAdmin = async (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: 'Войдите в аккаунт' });
  if (!(await isAdmin(req))) return res.status(403).json({ error: 'Нет доступа' });
  next();
};

const isDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s));

// создаём или обновляем администратора при старте
async function ensureAdmin() {
  const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
  await db.query(
    `INSERT INTO users (login, email, password_hash, is_admin)
     VALUES ($1, $1, $2, true)
     ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, is_admin = true`,
    [ADMIN_EMAIL, hash]
  );
}

// состояние базы: каких таблиц не хватает и сколько будущих рейсов.
// Имена без схемы, как в запросах приложения: проверяем то, что реально увидят запросы.
async function schemaState() {
  const { rows } = await db.query(`SELECT
    to_regclass('users') IS NOT NULL AS users,
    to_regclass('trains') IS NOT NULL AS trains,
    to_regclass('tickets') IS NOT NULL AS tickets,
    to_regclass('password_resets') IS NOT NULL AS password_resets,
    to_regclass('assistant_logs') IS NOT NULL AS assistant_logs,
    COALESCE((SELECT TRUE FROM pg_attribute
              WHERE attrelid = to_regclass('users') AND attname = 'is_admin' AND NOT attisdropped), FALSE) AS is_admin`);
  const r = rows[0];
  const missing = ['users', 'trains', 'tickets', 'password_resets', 'assistant_logs'].filter(t => !r[t]);
  let future = 0;
  if (r.trains) future = (await db.query('SELECT COUNT(*)::int AS n FROM trains WHERE depart_at > now()')).rows[0].n;
  return { ready: !missing.length && r.is_admin, missing, future };
}

// проверка базы при запуске: если таблиц нет или расписание кончилось, применяем schema.sql
async function checkDatabase() {
  try {
    let st = await schemaState();
    if (!st.ready || st.future === 0) {
      if (!st.ready) console.log('… База не настроена' + (st.missing.length ? ' (нет таблиц: ' + st.missing.join(', ') + ')' : '') + ', применяю schema.sql');
      else console.log('… В расписании нет будущих рейсов, дополняю его через schema.sql');
      await applySchema();
      st = await schemaState();
    }
    if (!st.ready) {
      console.error('✘ После schema.sql в базе всё ещё не хватает: ' + st.missing.join(', '));
      console.error('  ' + describe(await dbInfo()));
      return false;
    }
    console.log('✔ База готова: ' + describe(await dbInfo()));
    return true;
  } catch (e) {
    console.error('✘ Не удалось работать с базой: ' + errText(e));
    console.error('  ' + hintFor(e));
    return false;
  }
}

/* ---------- страницы ---------- */

app.get('/', async (req, res) => {
  const q = req.query;
  const searched = !!(q.from && q.to);
  let trains = [];

  if (searched) {
    const where = ['from_city ILIKE $1', 'to_city ILIKE $2', 'depart_at > now()'];
    const params = [q.from, q.to];

    if (q.date && isDate(q.date)) {
      params.push(q.date);
      where.push(`depart_at::date = $${params.length}::date`);
    }
    if (q.train_type) {
      params.push(q.train_type);
      where.push(`train_type = $${params.length}`);
    }
    if (q.max_price) {
      params.push(Number(q.max_price));
      where.push(`price_econom <= $${params.length}`);
    }
    if (q.time === 'morning') where.push('EXTRACT(HOUR FROM depart_at) < 12');
    if (q.time === 'day')     where.push('EXTRACT(HOUR FROM depart_at) BETWEEN 12 AND 17');
    if (q.time === 'evening') where.push('EXTRACT(HOUR FROM depart_at) >= 18');

    const sql = `SELECT * FROM trains WHERE ${where.join(' AND ')} ORDER BY depart_at`;
    trains = (await db.query(sql, params)).rows;
  }
  res.render('index', { title: 'Поиск поездов', trains, q, searched });
});

app.get('/dates', async (req, res) => {
  const { rows } = await db.query(
    `SELECT to_char(d::date, 'YYYY-MM-DD') AS day, COUNT(t.id)::int AS n
     FROM generate_series(current_date, current_date + 13, interval '1 day') d
     LEFT JOIN trains t ON t.depart_at::date = d::date
     GROUP BY 1 ORDER BY 1`
  );
  res.render('dates', { title: 'Расписание по датам', days: rows });
});

app.get('/date/:date', async (req, res) => {
  if (!isDate(req.params.date)) return res.status(404).render('notfound', { title: 'Не найдено' });
  const { rows } = await db.query(
    `SELECT * FROM trains WHERE depart_at::date = $1::date ORDER BY depart_at`,
    [req.params.date]
  );
  res.render('date', { title: 'Рейсы на дату', date: req.params.date, trains: rows });
});

app.get('/train/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(404).render('notfound', { title: 'Не найдено' });
  const { rows } = await db.query('SELECT * FROM trains WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).render('notfound', { title: 'Не найдено' });
  res.render('train', { title: `Рейс ${rows[0].number}`, t: rows[0] });
});

app.get('/login',    (req, res) => res.render('login', { title: 'Вход' }));
app.get('/register', (req, res) => res.render('register', { title: 'Регистрация' }));
app.get('/reset',    (req, res) => res.render('reset', { title: 'Сброс пароля' }));
app.get('/help',     (req, res) => res.render('help', { title: 'Помощь' }));

app.get('/tickets', async (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const { rows } = await db.query(
    `SELECT t.id, t.class, tr.number, tr.name, tr.from_city, tr.to_city,
            tr.depart_at, tr.arrive_at, tr.depart_at > now() AS can_return,
            CASE t.class WHEN 'coupe' THEN tr.price_coupe ELSE tr.price_econom END AS price
     FROM tickets t JOIN trains tr ON tr.id = t.train_id
     WHERE t.user_id = $1 ORDER BY tr.depart_at`,
    [req.session.user.id]
  );
  res.render('tickets', { tickets: rows, title: 'Мои билеты' });
});

// админ-панель: без входа администратора показываем форму входа
app.get('/admin', async (req, res) => {
  if (!(await isAdmin(req))) return res.render('admin_login', { title: 'Вход в админ-панель' });
  res.render('admin', { title: 'Админ-панель' });
});

/* ---------- регистрация / вход / выход ---------- */

app.post('/api/register', async (req, res) => {
  const { login, email, password, password2 } = req.body;
  if (!login || !email || !password) return res.status(400).json({ error: 'Заполните все поля' });
  if (password.length < 6)           return res.status(400).json({ error: 'Пароль минимум 6 символов' });
  if (password !== password2)        return res.status(400).json({ error: 'Пароли не совпадают' });

  try {
    const hash = await bcrypt.hash(password, 10);
    const { rows } = await db.query(
      'INSERT INTO users (login, email, password_hash) VALUES ($1, $2, $3) RETURNING id, login, is_admin',
      [login, email, hash]
    );
    req.session.user = { id: rows[0].id, login: rows[0].login, is_admin: rows[0].is_admin };
    res.json({ ok: true });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Логин или e-mail уже заняты' });
    console.error(e);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// вход по логину или e-mail
app.post('/api/login', async (req, res) => {
  const { login, password } = req.body;
  const { rows } = await db.query('SELECT * FROM users WHERE login = $1 OR email = $1', [login]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(password || '', u.password_hash)))
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  req.session.user = { id: u.id, login: u.login, is_admin: u.is_admin };
  res.json({ ok: true, is_admin: u.is_admin });
});

// вход в админ-панель: только для администраторов
app.post('/api/admin/login', async (req, res) => {
  const { login, password } = req.body;
  const { rows } = await db.query('SELECT * FROM users WHERE login = $1 OR email = $1', [login]);
  const u = rows[0];
  if (!u || !u.is_admin || !(await bcrypt.compare(password || '', u.password_hash)))
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  req.session.user = { id: u.id, login: u.login, is_admin: u.is_admin };
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));

/* ---------- сброс пароля ---------- */

app.post('/api/reset/request', async (req, res) => {
  const { login, email } = req.body;
  const { rows } = await db.query(
    'SELECT id FROM users WHERE login = $1 AND email = $2', [login, email]
  );
  if (rows[0]) {
    const code = String(crypto.randomInt(100000, 1000000));
    await db.query(
      `INSERT INTO password_resets (user_id, code_hash, expires_at)
       VALUES ($1, $2, now() + interval '15 minutes')`,
      [rows[0].id, await bcrypt.hash(code, 10)]
    );
    console.log(`Код сброса для ${email}: ${code}`); // в продакшене отправляй через nodemailer
  }
  res.json({ ok: true });
});

app.post('/api/reset/confirm', async (req, res) => {
  const { login, code, password } = req.body;
  if (!password || password.length < 6)
    return res.status(400).json({ error: 'Пароль минимум 6 символов' });

  const { rows } = await db.query(
    `SELECT pr.id, pr.user_id, pr.code_hash
     FROM password_resets pr JOIN users u ON u.id = pr.user_id
     WHERE u.login = $1 AND pr.expires_at > now()
     ORDER BY pr.id DESC LIMIT 1`, [login]
  );
  if (!rows[0] || !(await bcrypt.compare(String(code), rows[0].code_hash)))
    return res.status(400).json({ error: 'Неверный или просроченный код' });

  await db.query('UPDATE users SET password_hash = $1 WHERE id = $2',
    [await bcrypt.hash(password, 10), rows[0].user_id]);
  await db.query('DELETE FROM password_resets WHERE user_id = $1', [rows[0].user_id]);
  res.json({ ok: true });
});

/* ---------- билеты ---------- */

app.post('/api/tickets', needAuth, async (req, res) => {
  const { train_id, class: cls } = req.body;
  if (!['econom', 'coupe'].includes(cls)) return res.status(400).json({ error: 'Неверный класс' });
  const trainId = Number(train_id);
  if (!Number.isInteger(trainId)) return res.status(400).json({ error: 'Неверный поезд' });

  const { rows } = await db.query('SELECT depart_at > now() AS future FROM trains WHERE id = $1', [trainId]);
  if (!rows[0]) return res.status(404).json({ error: 'Поезд не найден' });
  if (!rows[0].future) return res.status(400).json({ error: 'Поезд уже отправился' });

  await db.query('INSERT INTO tickets (user_id, train_id, class) VALUES ($1, $2, $3)',
    [req.session.user.id, trainId, cls]);
  res.json({ ok: true });
});

app.post('/api/tickets/:id/return', needAuth, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Неверный билет' });
  const { rowCount } = await db.query(
    `DELETE FROM tickets t USING trains tr
     WHERE t.id = $1 AND t.user_id = $2 AND tr.id = t.train_id AND tr.depart_at > now()`,
    [id, req.session.user.id]
  );
  if (!rowCount) return res.status(400).json({ error: 'Билет нельзя вернуть: он не найден или поезд уже отправился' });
  res.json({ ok: true });
});

/* ---------- ассистент ---------- */

app.post('/api/assistant', async (req, res) => {
  const { topic, text } = req.body || {};
  const question = String(text || '').trim().slice(0, 300);
  const key = TOPICS.includes(topic) ? topic : null;

  let result;
  try {
    result = await answer(db, { text: question, topic: key, user: req.session.user });
  } catch (e) {
    console.error('assistant failed:', e.message);
    return res.status(500).json({ error: 'Ассистент временно недоступен' });
  }

  try {
    await db.query(
      'INSERT INTO assistant_logs (question, topic, answered) VALUES ($1, $2, $3)',
      [question || `[кнопка: ${result.topic}]`, result.topic, result.topic !== 'unknown']
    );
  } catch (e) {
    console.error('assistant log failed:', e.message);
  }
  res.json({ topic: result.topic, answer: result.answer, links: result.links || [] });
});

/* ---------- админ-панель: статистика ---------- */

app.get('/api/admin/assistant-stats', needAdmin, async (req, res) => {
  const period = "created_at > now() - interval '7 days'";
  const [totals, byTopic, byDay, unanswered] = await Promise.all([
    db.query(`SELECT COUNT(*)::int AS total,
                     COUNT(*) FILTER (WHERE answered)::int AS answered
              FROM assistant_logs WHERE ${period}`),
    db.query(`SELECT topic, COUNT(*)::int AS n FROM assistant_logs
              WHERE ${period} GROUP BY topic ORDER BY n DESC`),
    db.query(`SELECT created_at::date AS day, COUNT(*)::int AS n FROM assistant_logs
              WHERE ${period} GROUP BY 1 ORDER BY 1`),
    db.query(`SELECT question, COUNT(*)::int AS n FROM assistant_logs
              WHERE NOT answered AND ${period} GROUP BY question ORDER BY n DESC LIMIT 10`)
  ]);
  const t = totals.rows[0];
  res.json({
    total: t.total,
    answered: t.answered,
    answeredShare: t.total ? Math.round((t.answered / t.total) * 100) : 0,
    byTopic: byTopic.rows,
    byDay: byDay.rows,
    unanswered: unanswered.rows
  });
});

// удалить вопрос из блока «Требуют внимания» (все его записи без ответа)
app.post('/api/admin/assistant-unanswered/delete', needAdmin, async (req, res) => {
  const question = String((req.body || {}).question || '');
  if (!question) return res.status(400).json({ error: 'Не указан вопрос' });
  const { rowCount } = await db.query(
    'DELETE FROM assistant_logs WHERE NOT answered AND question = $1', [question]
  );
  res.json({ ok: true, deleted: rowCount });
});

/* ---------- админ-панель: рейсы, пользователи, билеты ---------- */

app.get('/api/admin/trains', needAdmin, async (req, res) => {
  const { rows } = await db.query(
    `SELECT id, number, name, from_city, to_city, depart_at, price_econom, price_coupe
     FROM trains WHERE depart_at > now() ORDER BY depart_at LIMIT 200`
  );
  res.json(rows);
});

app.post('/api/admin/trains', needAdmin, async (req, res) => {
  const b = req.body || {};
  const required = ['number', 'from_city', 'to_city', 'depart_at', 'arrive_at', 'price_econom', 'price_coupe'];
  if (required.some(k => !b[k])) return res.status(400).json({ error: 'Заполните все обязательные поля' });
  if (!(Number(b.price_econom) > 0 && Number(b.price_coupe) > 0))
    return res.status(400).json({ error: 'Цены должны быть больше нуля' });
  if (Date.parse(b.arrive_at) <= Date.parse(b.depart_at))
    return res.status(400).json({ error: 'Прибытие должно быть позже отправления' });

  await db.query(
    `INSERT INTO trains (number, name, train_type, from_city, to_city, from_station, to_station,
                         depart_at, arrive_at, price_econom, price_coupe)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
    [b.number, b.name || null, b.train_type || 'скоростной', b.from_city, b.to_city,
     b.from_station || null, b.to_station || null, b.depart_at, b.arrive_at,
     Number(b.price_econom), Number(b.price_coupe)]
  );
  res.json({ ok: true });
});

app.delete('/api/admin/trains/:id', needAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Неверный рейс' });
  try {
    const { rowCount } = await db.query('DELETE FROM trains WHERE id = $1', [id]);
    if (!rowCount) return res.status(404).json({ error: 'Рейс не найден' });
    res.json({ ok: true });
  } catch (e) {
    if (e.code === '23503') return res.status(409).json({ error: 'На рейс уже куплены билеты, удалить нельзя' });
    throw e;
  }
});

app.get('/api/admin/users', needAdmin, async (req, res) => {
  const { rows } = await db.query(
    'SELECT id, login, email, is_admin, created_at FROM users ORDER BY id DESC LIMIT 200'
  );
  res.json(rows);
});

// ---- администраторы: добавление, снятие прав, удаление ----

// главный администратор задаётся в .env и пересоздаётся при каждом запуске, поэтому его защищаем
const isMainAdmin = u => String(u.email).toLowerCase() === ADMIN_EMAIL.toLowerCase();
const adminCount = async () => (await db.query('SELECT COUNT(*)::int AS n FROM users WHERE is_admin')).rows[0].n;

// выдать или снять права у существующего пользователя
app.post('/api/admin/users/:id/admin', needAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Неверный пользователь' });
  const makeAdmin = !!(req.body && req.body.is_admin);

  const { rows } = await db.query('SELECT id, email, is_admin FROM users WHERE id = $1', [id]);
  const u = rows[0];
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });

  if (!makeAdmin) {
    if (id === req.session.user.id) return res.status(400).json({ error: 'Нельзя снять права у себя' });
    if (isMainAdmin(u)) return res.status(400).json({ error: 'Главного администратора нельзя лишить прав: он задаётся в .env' });
    if (u.is_admin && (await adminCount()) <= 1) return res.status(400).json({ error: 'Нельзя снять права у последнего администратора' });
  }
  await db.query('UPDATE users SET is_admin = $1 WHERE id = $2', [makeAdmin, id]);
  res.json({ ok: true });
});

// список администраторов
app.get('/api/admin/admins', needAdmin, async (req, res) => {
  const { rows } = await db.query(
    'SELECT id, login, email, created_at FROM users WHERE is_admin ORDER BY id'
  );
  res.json(rows.map(u => ({
    ...u,
    is_main: isMainAdmin(u),
    is_self: u.id === req.session.user.id
  })));
});

// создать нового администратора
app.post('/api/admin/admins', needAdmin, async (req, res) => {
  const b = req.body || {};
  const login = String(b.login || '').trim();
  const email = String(b.email || '').trim();
  const password = String(b.password || '');
  if (!login || !email || !password) return res.status(400).json({ error: 'Заполните логин, e-mail и пароль' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Неверный e-mail' });
  if (password.length < 6) return res.status(400).json({ error: 'Пароль минимум 6 символов' });

  try {
    await db.query(
      'INSERT INTO users (login, email, password_hash, is_admin) VALUES ($1, $2, $3, true)',
      [login, email, await bcrypt.hash(password, 10)]
    );
    res.json({ ok: true });
  } catch (e) {
    if (e.code === '23505') {
      return res.status(409).json({ error: 'Логин или e-mail уже заняты. Если пользователь уже есть, выдайте ему права на вкладке «Пользователи»' });
    }
    throw e;
  }
});

// удалить администратора вместе с аккаунтом (его билеты тоже удаляются)
app.delete('/api/admin/admins/:id', needAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Неверный администратор' });

  const { rows } = await db.query('SELECT id, email, is_admin FROM users WHERE id = $1', [id]);
  const u = rows[0];
  if (!u || !u.is_admin) return res.status(404).json({ error: 'Администратор не найден' });
  if (id === req.session.user.id) return res.status(400).json({ error: 'Нельзя удалить самого себя' });
  if (isMainAdmin(u)) return res.status(400).json({ error: 'Главного администратора нельзя удалить: он задаётся в .env' });
  if ((await adminCount()) <= 1) return res.status(400).json({ error: 'Нельзя удалить последнего администратора' });

  await db.query('DELETE FROM users WHERE id = $1', [id]);
  res.json({ ok: true });
});

app.get('/api/admin/tickets', needAdmin, async (req, res) => {
  const { rows } = await db.query(
    `SELECT t.id, t.class, t.created_at, u.login, tr.number, tr.from_city, tr.to_city, tr.depart_at
     FROM tickets t JOIN users u ON u.id = t.user_id JOIN trains tr ON tr.id = t.train_id
     ORDER BY t.created_at DESC LIMIT 200`
  );
  res.json(rows);
});

/* ---------- 404 и ошибки ---------- */

app.use((req, res) => res.status(404).render('notfound', { title: 'Не найдено' }));

app.use((err, req, res, next) => {
  console.error(err);
  // причину показываем, только если сервер запущен не в режиме production
  const detail = process.env.NODE_ENV === 'production' ? '' : String(err && err.message || err);
  if (req.path.startsWith('/api/'))
    return res.status(500).json({ error: 'Ошибка сервера' + (detail ? ': ' + detail : '') });
  res.status(500).render('error', { title: 'Ошибка', detail });
});

const port = process.env.PORT || 3000;
checkDatabase()
  .then(ok => ok ? ensureAdmin().then(() => console.log('✔ Администратор готов: ' + ADMIN_EMAIL)) : null)
  .catch(e => console.error('✘ Не удалось создать администратора:', e.message))
  .finally(() => app.listen(port, () => console.log(`Сервер запущен: http://localhost:${port}`)));
