// Применяет schema.sql к базе из .env: создаёт таблицы и дополняет расписание.
// Запуск вручную: npm run db:setup. Сервер вызывает applySchema() сам, если таблиц нет.
require('dotenv').config({ quiet: true });
const fs = require('fs');
const path = require('path');
const db = require('./db');

async function applySchema() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await db.query(sql);
}

// где мы подключены и что в базе: помогает понять, та ли это база
async function dbInfo() {
  const { rows } = await db.query(
    `SELECT current_database() AS db, current_user AS usr, current_schema() AS sch,
            to_regclass('trains') IS NOT NULL AS has_trains`
  );
  const r = rows[0];
  let total = 0, future = 0;
  if (r.has_trains) {
    const t = (await db.query(
      'SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE depart_at > now())::int AS future FROM trains'
    )).rows[0];
    total = t.total;
    future = t.future;
  }
  return { ...r, total, future };
}

const describe = i =>
  `база «${i.db}», пользователь «${i.usr}», схема «${i.sch}», рейсов: ${i.total} (будущих: ${i.future})`;

// текст ошибки: у ошибок подключения на новых версиях Node message бывает пустым
function errText(e) {
  return e.message
    || (e.errors && e.errors.map(x => x.message || x.code).filter(Boolean).join('; '))
    || e.code
    || String(e);
}

// подсказка по коду ошибки
function hintFor(e) {
  const code = e.code || (e.errors && e.errors[0] && e.errors[0].code);
  if (code === '42501') return 'У пользователя базы нет прав создавать таблицы. Выполните от имени администратора базы: GRANT ALL ON SCHEMA public TO <пользователь из DATABASE_URL>;';
  if (code === '28P01' || code === '28000') return 'Неверный логин или пароль в DATABASE_URL.';
  if (code === '3D000') return 'Базы с таким именем нет. Создайте её (CREATE DATABASE имя;) или исправьте имя в DATABASE_URL.';
  if (code === 'ECONNREFUSED' || code === 'ENOTFOUND') return 'PostgreSQL не отвечает. Проверьте, что он запущен, а адрес и порт в DATABASE_URL верные.';
  return 'Проверьте, что PostgreSQL запущен и что в .env верный DATABASE_URL (пример: postgres://пользователь:пароль@localhost:5432/имя_базы).';
}

module.exports = { applySchema, dbInfo, describe, errText, hintFor };

if (require.main === module) {
  applySchema()
    .then(() => dbInfo())
    .then(info => console.log('✔ schema.sql применён: ' + describe(info)))
    .catch(e => {
      console.error('✘ Не удалось применить schema.sql: ' + errText(e));
      console.error('  ' + hintFor(e));
      process.exitCode = 1;
    })
    .finally(() => db.end().catch(() => {}));
}
