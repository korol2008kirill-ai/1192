// Применяет schema.sql к базе из .env: создаёт таблицы и дополняет расписание.
// Запуск вручную: npm run db:setup. Сервер вызывает applySchema() сам, если таблиц нет.
require('dotenv').config({ quiet: true });
const fs = require('fs');
const path = require('path');
const db = require('./db');

async function applySchema() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await db.query(sql);
}

module.exports = { applySchema };

if (require.main === module) {
  applySchema()
    .then(() => console.log('✔ schema.sql применён: таблицы созданы, расписание дополнено'))
    .catch(e => {
      console.error('✘ Не удалось применить schema.sql: ' + e.message);
      console.error('  Проверьте DATABASE_URL в .env и что PostgreSQL запущен.');
      process.exitCode = 1;
    })
    .finally(() => db.end().catch(() => {}));
}
