# Поезда: сайт бронирования билетов

Node.js + Express + EJS + PostgreSQL.

## Запуск

1. Установите зависимости: `npm install`
2. Создайте файл `.env` (в репозиторий его не коммитим):

       DATABASE_URL=postgres://user:password@localhost:5432/rzd
       SESSION_SECRET=длинная_случайная_строка

3. Создайте базу и примените схему: `psql "$DATABASE_URL" -f schema.sql`
4. Запустите сервер: `npm start`, затем откройте http://localhost:3000

## Администратор

Роль выдаётся вручную:

    UPDATE users SET is_admin = true WHERE login = 'ваш_логин';

После этого в шапке появляется раздел «Статистика» со статистикой ассистента.

## Ассистент

Чат есть на всех страницах. Ответы готовые (`assistant.js`), обращения записываются в `assistant_logs`
без привязки к пользователю.
