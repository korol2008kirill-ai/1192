CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  login TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- если таблица users уже создана раньше, добавляем роль
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS trains (
  id SERIAL PRIMARY KEY,
  number TEXT NOT NULL,            -- '072А'
  name TEXT,                       -- 'САПСАН'
  train_type TEXT DEFAULT 'скоростной',
  from_city TEXT NOT NULL,
  to_city TEXT NOT NULL,
  from_station TEXT,               -- 'Ленинградский'
  to_station TEXT,                 -- 'СПб Гл.'
  depart_at TIMESTAMPTZ NOT NULL,
  arrive_at TIMESTAMPTZ NOT NULL,
  price_econom INT NOT NULL,
  price_coupe INT NOT NULL
);

CREATE TABLE IF NOT EXISTS tickets (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  train_id INT NOT NULL REFERENCES trains(id),
  class TEXT NOT NULL,             -- 'econom' | 'coupe'
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS password_resets (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL
);

-- журнал обращений к ассистенту (без привязки к пользователю)
CREATE TABLE IF NOT EXISTS assistant_logs (
  id SERIAL PRIMARY KEY,
  question TEXT NOT NULL,
  topic TEXT NOT NULL,
  answered BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- тестовое расписание: 31 день, по 3 рейса в день на каждом направлении
INSERT INTO trains
(number, name, train_type, from_city, to_city, from_station, to_station, depart_at, arrive_at, price_econom, price_coupe)
SELECT r.number, r.name, r.train_type, r.from_city, r.to_city, r.from_station, r.to_station,
       (current_date + d) + t.dep,
       (current_date + d) + t.dep + r.dur,
       r.price_econom, r.price_coupe
FROM (VALUES
  ('072А', 'САПСАН',    'скоростной',  'Москва',           'Санкт-Петербург',  'Ленинградский', 'СПб Гл.',                  interval '3 hours 50 minutes', 2450, 4100),
  ('072А', 'САПСАН',    'скоростной',  'Санкт-Петербург',  'Москва',           'СПб Гл.',       'Ленинградский',            interval '3 hours 50 minutes', 2450, 4100),
  ('758А', 'ЛАСТОЧКА',  'скоростной',  'Москва',           'Нижний Новгород',  'Курский',       'Московский',               interval '4 hours 10 minutes', 1650, 3100),
  ('010Т', 'ТАТАРСТАН', 'скоростной',  'Москва',           'Казань',           'Казанский',     'Казань-Пассажирская',      interval '12 hours 30 minutes', 2100, 3900),
  ('011Т', 'ТАТАРСТАН', 'скоростной',  'Казань',           'Москва',           'Казань-Пассажирская', 'Казанский',          interval '12 hours 30 minutes', 2100, 3900),
) AS r(number, name, train_type, from_city, to_city, from_station, to_station, dur, price_econom, price_coupe)
CROSS JOIN generate_series(0, 30) AS d
CROSS JOIN LATERAL (VALUES (time '07:15'), (time '13:40'), (time '19:05')) AS t(dep)
WHERE NOT EXISTS (SELECT 1 FROM trains);
